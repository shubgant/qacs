﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StockTicker
{
    public class RootObject
    {
        public List<Company> BestMatches { get; set; }
    }
}
