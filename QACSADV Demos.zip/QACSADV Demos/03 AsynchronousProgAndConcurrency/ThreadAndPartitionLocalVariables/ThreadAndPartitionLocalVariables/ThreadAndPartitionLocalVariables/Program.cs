﻿namespace ThreadAndPartitionLocalVariables
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ThreadLocal.Demo();
            PartitionLocal.Demo();
        }
    }
}
