public interface IDiscount {
	decimal GetDiscount(decimal TotalSales);
}