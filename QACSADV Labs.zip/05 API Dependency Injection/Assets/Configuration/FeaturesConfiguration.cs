﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuickTour.Configuration
{
    public class FeaturesConfiguration
    {
        public bool EnableMyOption1 { get; set; }
        public bool EnableMyOption2 { get; set; }
    }
}
