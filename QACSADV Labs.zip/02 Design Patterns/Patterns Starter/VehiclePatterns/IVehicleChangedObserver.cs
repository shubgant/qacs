﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehiclePatterns
{
    public interface IVehicleChangedObserver
    {

        //Require classes implementing this interface to have a Void method named Update with paramater of type IVehicle
       
    }
}
