﻿namespace DependencyInjectionDemo.Models
{
    public class GreetingSettings
    {
        public string Prefix { get; set; }
        public string Suffix { get; set; }
    }
}
