﻿namespace DependencyInjectionDemo.Services
{
    public interface IGreetingService
    {
        string Greet(string name);
    }
}
